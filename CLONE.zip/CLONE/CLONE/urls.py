"""
URL configuration for CLONE project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from JIO_MART import views

urlpatterns = [
    # path('', include('JIO_MART.urls')),
    path('JIO_MART/', views.JIO_MART),
    path('Groceries/', views.Groceries),
    

    path('Fashion/', views.Fashion),
   
    path('Electronic/', views.Electronics),
  
    path('About/', views.About),
    path('Register/', views.Register),
    path('Login/', views.Login),

    path('admin/', admin.site.urls),
]
