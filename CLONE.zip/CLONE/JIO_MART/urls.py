from django.urls import path
from . import views

urlpatterns = [
    path('JIO_MART/', views.JIO_MART, name='JIO_MART'),
]