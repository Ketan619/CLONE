# from django.db import models

from django.db import models
from django.db.models import Model
class Review(models.Model):
 
  username = models.CharField(max_length=255)
  email = models.CharField(max_length=255)
  Review = models.TextField( )


  def __str__(self):
    return 'Username:' + ' '+self.username 