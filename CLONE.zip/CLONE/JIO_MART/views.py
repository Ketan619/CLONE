from .models import Review
from django.template import loader
from django.contrib.auth.models import User
from django.shortcuts import render,HttpResponse ,redirect
from django.contrib import messages
from django.contrib.auth import authenticate ,login
def JIO_MART(request):




  return render(request,'JIO_MART.html')
  
def Groceries(request):
  return render(request,'Groceries.html')
  
def Fashion(request):
  return render(request,'Fashion.html')
  
def Electronics(request):
  return render(request,'Electronics.html')
  
def Register(request):
 

      
  if request.method=="POST":
    username=request.POST['first_name']
    email=request.POST['email']
    password=request.POST['pwd']
    RE_password=request.POST['REpwd']
    print(username,email,password,RE_password)


    if len(username)<5 or  len(password)<5 and password!=RE_password:
     messages.error(request,"please fill form correctly")
    else:
     data=User.objects.create_user(username=username ,email=email,password=password)
     data.save()
     messages.success(request,'Welcome to JIO MART')
    #  data= post(username=username ,email=email,password=password)

  return render(request,'Register.html')


def Login(request):
   if request.method=="POST":
    LOGIN_user=request.POST['loginuser']
    LOGIN_password=request.POST['loginpass']
    user=authenticate(username=LOGIN_user,password=LOGIN_password)
    if user is not  None:
      login(request,user)
      messages.success(request,'Successful Logged In')
      return  redirect ('/Login/')
    else:
       messages.error(request,'Invalid Details try Again')
       return  redirect ('/Login/')
       
   return render(request,'Login.html')



def About(request):
  return render( request,'about.html')







    



  


