from django.apps import AppConfig


class JioMartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'JIO_MART'
